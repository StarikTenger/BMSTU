#!/bin/bash
sleep 1
echo qqq